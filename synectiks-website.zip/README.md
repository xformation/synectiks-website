Putting it all together

Just run:

webpack

Now open up index.html in your favorite browser and everything should be ready to use! This is for local testing , finally the index.html file along with bundle.js is deployed in s3.
