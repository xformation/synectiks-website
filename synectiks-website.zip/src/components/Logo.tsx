import * as React from 'react'
import * as ReactDOM from 'react-dom'
import ReactSVG from 'react-svg'


// tslint:disable-next-line:variable-name
class Logo extends React.Component<{}, {}> {
    render() {
        return <div>
        <ReactSVG src="logo.svg" />
        <p>MyLogo</p>
      </div>;
    }
}
export default Logo;