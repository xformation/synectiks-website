import * as React from "react";
import "./background.css";

import Particles from "react-particles-js";

class Background extends React.Component {
  public render() {
    return (
      <div id="particle-js">
        <Particles
          params={{
            particles: {
              number: {
                value: 10,
                density: {
                  enable: true,
                  value_area: 800
                }
              },
              line_linked: {
                enable: false
              },
              move: {
                speed: 1,
                out_mode: "out"
              },
              shape: {
                type: ["circle", "polygon", "triangle"]
                // images: [
                //   {
                //     src: "img/html.png",
                //     height: 20,
                //     width: 23
                //   },
                //   {
                //     src: "img/js.png",
                //     height: 20,
                //     width: 20
                //   },
                //   {
                //     src: "img/jscode.png",
                //     height: 20,
                //     width: 20
                //   },
                //   {
                //     src: "img/ts.png",
                //     height: 20,
                //     width: 20
                //   },
                //   {
                //     src: "img/node.png",
                //     height: 20,
                //     width: 20
                //   }
                // ]
              },
              color: {
                value: "#CCC"
              },
              size: {
                value: 20,
                random: false,
                anim: {
                  enable: true,
                  speed: 4,
                  size_min: 10,
                  sync: false
                }
              }
            },
            retina_detect: true
          }}
        />
      </div>
    );
  }
}

export default Background;
