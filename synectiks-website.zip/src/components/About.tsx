import * as React from "react";
// import { Link } from "react-router-dom";

export const About: React.StatelessComponent<{}> = () => {
  return (
    <div className="row col-12">
      <p>About Us Page</p>
    </div>
  );
};
