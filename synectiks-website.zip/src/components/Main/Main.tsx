import * as React from "react";
import { Link } from "react-router-dom";

export const Main: React.StatelessComponent<{}> = () => {
  return (
    <div className="container">
      <div className="row main-card">
        <div className="col-md-12 col-12-lg card-deck">
          <div className="card card-shadow">
            <img
              className="card-img-top"
              src="img/Foundation.png"
              alt="Card image cap"
            />
            <div className="card-body">
              <h2 className="text-center text-uppercase">Foundation</h2>
            </div>
          </div>
          <div className="card card-shadow mx-5">
            <img
              className="card-img-top"
              src="img/Transformation.png"
              alt="Card image cap"
            />

            <div className="card-body">
              <h2 className="text-center text-uppercase">Transformation</h2>
            </div>
          </div>
          <div className="card card-shadow">
            <img
              className="card-img-top"
              src="img/Operation.png"
              alt="Card image cap"
            />
            <div className="card-body">
              <h2 className="text-center text-uppercase">Operation</h2>
            </div>
          </div>
        </div>
      </div>
      <div className="d-flex">
        <div className="p-2 flex-fill">
          <img src="img/jumbotron.png" alt="" className="w-100" />
          <div />
        </div>
      </div>
    </div>
  );
};
