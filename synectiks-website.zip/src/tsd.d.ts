declare module "*.svg" {
    const content:string;
    export default content;
  }
/// <reference types="react-scripts" />